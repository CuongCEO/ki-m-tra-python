A = [1,1,2,6,8,9,4,5,6,45,34,66,44,37,78]
B = []
print("Các số nhỏ hơn 30 là: ")
cho x trong A:
	nếu x < 30:
		in(x)
		B. thêmvào (x)
in(B)
n = input("nhập n:")
n = int(n)
print("Các số nhỏ hơn n là:")
cho x trong A:
	nếu x > n:
		in(x)